# Farmers_Company
Farmer's Company Project is based on C++, Here whole Farming from Producing the crop what are the requirements of the crop, then the required chemicals for different types of soil, then selling the crop E-marketing all the requirements can be managed using this Mini Project
